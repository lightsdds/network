#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>

#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>

// Included to get the support library
#include <calcLib.h>

// Enable if you want debugging to be printed, see examble below.
// Alternative, pass CFLAGS=-DDEBUG to make, make CFLAGS=-DDEBUG
#define DEBUG
// Remove comment to add 10s delay to client
// #define DELAY
#define MAXDATASIZE 1400
#define ACCEPT_VERSION "TEXT TCP 1.0\n\n"

using namespace std;

int main(int argc, char *argv[]) {
  // disables debugging when there's no DEBUG macro defined
#ifndef DEBUG
  cout.setstate(ios_base::failbit);
  cerr.setstate(ios_base::failbit);
#endif

  /*
    Read first input, assumes <ip>:<port> syntax, convert into one string
    (Desthost) and one integer (port). Atm, works only on dotted notation, i.e.
    IPv4 and DNS. IPv6 does not work if its using ':'.
  */
  char delim[] = ":";
  char *Desthost = strtok(argv[1], delim);
  char *Destport = strtok(NULL, delim);
  // *Desthost now points to a sting holding whatever came before the delimiter,
  // ':'. *Dstport points to whatever string came after the delimiter.

  /* Do magic */
  int port = atoi(Destport);
  printf("Host %s, and port %d.\n", Desthost, port);
  
  int sockFd, rv, byteSize;
	struct addrinfo hints, *servinfo, *ptr;
	char buffer[MAXDATASIZE];
	char s[INET6_ADDRSTRLEN];

  timeval timeout;
  timeout.tv_sec = 5;
  timeout.tv_usec = 0;

  memset(&hints, 0, sizeof hints);

	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

  rv = getaddrinfo(Desthost, Destport, &hints, &servinfo);

	for(ptr = servinfo; ptr != NULL; ptr = ptr->ai_next) {
    // creating socket
		if((sockFd = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol)) == -1) {
			cerr << "talker: socket\n";
			continue;
		}

		break;
	}

  if (ptr == NULL) {
		cerr << "talker: failed to create socket\n";
    exit(-1);
	}

  // connecting to established socket
  connect(sockFd,ptr->ai_addr, ptr->ai_addrlen);

  sockaddr_in cli_addr;
  socklen_t len = sizeof(cli_addr);
  if (getsockname(sockFd, (struct sockaddr *)&cli_addr, &len) < 0) {
    printf("getsockname failed");
    return -1;
  }

  printf("Connected to %s:%s local %s:%d\n", Desthost, Destport, inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));

  inet_ntop(ptr->ai_family, getSocketAddress((struct sockaddr *)ptr->ai_addr),
		  s, sizeof s);
	
	freeaddrinfo(servinfo);

  setsockopt(sockFd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof timeout);

  byteSize = recv(sockFd, buffer, MAXDATASIZE-1, 0);
  buffer[byteSize] = '\0';
	
  cout << buffer;

  if(strcmp(buffer, ACCEPT_VERSION) != 0){
    cerr << "invalid version\n";
  }
  // send ok
  printf("OK\n");
  send(sockFd, "OK\n", 3, 0);

  byteSize = recv(sockFd, buffer, MAXDATASIZE-1, 0);
  buffer[byteSize] = '\0';

  printf("%s\n", buffer);

  auto result = calculateTask(strtok(buffer, "\n"));
  cout << result->result;

  send(sockFd, result->result, strlen(result->result), 0);

  byteSize = recv(sockFd, buffer, MAXDATASIZE-1, 0);
  buffer[byteSize] = '\0';

  if(strcmp(buffer, "OK\n") != 0){
    if(strcmp(buffer, "ERROR\n") != 0){
      printf("ERROR TO\n");
    }
    else{
      printf("%s", buffer);
    }

    close(sockFd);
    exit(-1);
  }
  
  printf("OK (myresult=%s)\n", strtok(result->result, "\n"));

  close(sockFd);
  return 0;
}